# alexjpate.com

👋 Welcome to the source code of my [personal site](https://alexjpate.com).

## Installation

How to get this site running locally:

- `git clone https://github.com/alexpate/www`
- `npm install`
- To develop the site: `npm run dev`
- To build the site for production: `npm run build`
- The site should now be running at http://localhost:3000

## Say hello!

Feel free to say hello over on twitter [@alexjpate](http://twitter.com/alexjpate).
